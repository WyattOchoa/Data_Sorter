import tkinter as tk

HEIGHT=700
WIDTH=800

def test_function():
    print("Button Clicked!")

root = tk.Tk()
#root window for tkinter
canvas = tk.Canvas(root, height=HEIGHT, width=WIDTH)
canvas.pack()

frame = tk.Frame(root, bg='#ACC3FC')
frame.place(relx=.1, rely=.1, relwidth=.8, relheight=.8)

button = tk.Button(frame, text="Test Button", bg="pink", command=test_function)
#defines the button and its attributes
button.place(relx=.01, rely=.01, relwidth=.25, relheight=.25)
#places button on screen

label = tk.Label(frame, text="This is a label", bg="yellow" )
label.place(relx=.27, rely=.01, relwidth=.25, relheight=.25)

entry = tk.Entry(frame, bg="#acfcb0")
entry.place(relx=.53, rely=.01, relwidth=.25, relheigh=.25)

root.mainloop()
