import pandas as pd
#imports the panda library

print("""Welcome to the Data Sorter V.1.0
---------------------------------
Menu options:
1:Computer Name Alphabetically
2:Computer Name Alphabetically descending
3:IPs Ascending
4:IPs Descending
5:Capture Date
6:Missing Patches
7:Quit
---------------------------------""")

available_choices = ["1", "2", "3", "4", "5", "6"]

user_choice = ""
while user_choice not in available_choices:
    user_choice = input("Please enter what you would like to do with your data: ")
    #While loop that fufils error handling
    if user_choice == "7":
        print("Goodbye")
        break
    #Quits the program if the user chooses 7

user_file = pd.read_csv('TestCompInfo.csv')
#Todo replace with a user inputted file

if user_choice == "1":
    user_file = (user_file.sort_values('Name'))
    user_file.to_csv('Alphabetized.csv', index=False)

elif user_choice == "2":
    user_file = (user_file.sort_values('Name', ascending=False))
    user_file.to_csv('Alphabetized_Desc.csv', index=False)

elif user_choice == "3":
    user_file = (user_file.sort_values('IPs'))
    user_file.to_csv('IP_Asc.csv', index=False)

elif user_choice == "4":
    user_file = (user_file.sort_values('IPs Desc.', ascending=False))
    user_file.to_csv('IP_Desc.csv', index=False)

elif user_choice == "5":
    user_file = (user_file.sort_values('Date Captured'))
    user_file.to_csv('Date_Captured.csv', index=False)

elif user_choice == "6":
    user_file = (user_file.sort_values('Missing Patches'))
    user_file.to_csv('Missing_Patches.csv', index=False)

