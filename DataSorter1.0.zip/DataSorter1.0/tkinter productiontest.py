import tkinter as tk

root = tk.Tk()
#root window for tkinter
canvas = tk.Canvas(root, height=700, width=500)
canvas.pack()

backround_image=tk.PhotoImage(file='background.png')
backround_image=tk.Label(root, image=backround_image)
backround_image.place(relwidth=1, relheight=1)
#TODO Come back to this section to apply backround image behind frames

topframe = tk.Frame(root, bg='#21c2c4')
topframe.place(relx=.01, rely=.01, relwidth=.98, relheight=.2)
#Establishes a frame in root to house other widgets

label = tk.Label(topframe, text="Step 1: Select CSV File for Analysis:", bg="#ceded2" )
label.place(relx=.01, rely=.02, relwidth=.40, relheight=.15)

button = tk.Button(topframe, text="Browse", bg="yellow")
#defines the button and its attributes
button.place(relx=.42, rely=.02, relwidth=.1, relheight=.15)

label = tk.Label(topframe, text="", bg="white" )
label.place(relx=.01, rely=.20, relwidth=.98, relheight=.30)

midframe = tk.Frame(root, bg='#21c2c4')
midframe.place(relx=.01, rely=.22, relwidth=.98, relheight=.35)
#Label, then buttons in 3x2

label = tk.Label(midframe, text="Step 2: How would you like the data sorted?", bg="#ceded2" )
label.place(relx=.01, rely=.02, relwidth=.50, relheight=.10)

button = tk.Button(midframe, text="Alphabetized", bg="pink")
#defines the button and its attributes
button.place(relx=.01, rely=.2, relwidth=.3, relheight=.25)

button = tk.Button(midframe, text="IPs", bg="pink")
#defines the button and its attributes
button.place(relx=.35, rely=.2, relwidth=.3, relheight=.25)

button = tk.Button(midframe, text="Date Captured", bg="pink")
#defines the button and its attributes
button.place(relx=.69, rely=.2, relwidth=.3, relheight=.25)

button = tk.Button(midframe, text="Alphabetized Desc.", bg="pink")
#defines the button and its attributes
button.place(relx=.01, rely=.6, relwidth=.3, relheight=.25)

button = tk.Button(midframe, text="IPs Desc.", bg="pink")
#defines the button and its attributes
button.place(relx=.35, rely=.6, relwidth=.3, relheight=.25)

button = tk.Button(midframe, text="Missing Patches", bg="pink")
#defines the button and its attributes
button.place(relx=.69, rely=.6, relwidth=.3, relheight=.25)
#places button on screen

bottomframe = tk.Frame(root, bg='#21c2c4')
bottomframe.place(relx=.01, rely=.58, relwidth=.98, relheight=.2)
#Label, Button, Label
label = tk.Label(bottomframe, text="Step 3: Select output location for sorted File:", bg="#ceded2" )
label.place(relx=.01, rely=.02, relwidth=.50, relheight=.15)

button = tk.Button(bottomframe, text="Browse", bg="yellow")
#defines the button and its attributes
button.place(relx=.52, rely=.02, relwidth=.1, relheight=.15)

label = tk.Label(bottomframe, text="", bg="white" )
label.place(relx=.01, rely=.20, relwidth=.98, relheight=.30)

sortframe = tk.Frame(root, bg='#21c2c4')
sortframe.place(relx=.01, rely=.79, relwidth=.98, relheight=.2)

label = tk.Label(sortframe, text="Step 4: Click SORT! to complete sorting", bg="#ceded2" )
label.place(relx=.01, rely=.02, relwidth=.45, relheight=.15)

button = tk.Button(sortframe, text="Sort!", bg="Orange")
#defines the button and its attributes
button.place(relx=.1, rely=.3, relwidth=.80, relheight=.50)
#places button on screen


root.mainloop()
