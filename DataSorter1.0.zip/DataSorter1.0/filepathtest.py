import PySimpleGUI as sg
import tkinter as tk

sg.Window(title="hello world", layout=[[]], margins=(1000, 500)).read()