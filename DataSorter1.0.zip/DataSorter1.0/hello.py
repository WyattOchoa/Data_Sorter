from tkinter import *
from tkinter import ttk
root = Tk()
ttk.Button(root, text="Hello").grid()
root.mainloop()