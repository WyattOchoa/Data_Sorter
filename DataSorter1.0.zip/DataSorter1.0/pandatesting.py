import pandas as pd
#imports the panda library

df = pd.read_csv('pokemon_data.csv')
#assigns the df variable to reach the pokemon_data.csv
df = (df.sort_values('Name'))
df.to_csv('modified1.csv', index=False)



